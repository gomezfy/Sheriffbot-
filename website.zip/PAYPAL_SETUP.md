# PayPal Integration Setup - Sheriff Bot Website

## 📋 Requirements

- Node.js 20+
- PayPal Developer Account
- Express + TypeScript

## 🔑 Getting PayPal Credentials

### 1. Create PayPal Developer Account
1. Go to [developer.paypal.com](https://developer.paypal.com)
2. Log in with your PayPal account (or create one)
3. Accept the developer terms

### 2. Create a REST API App
1. Navigate to **Dashboard** → **My Apps & Credentials**
2. Select **Sandbox** tab (for testing) or **Live** (for production)
3. Click **Create App**
4. Enter app name: `Sheriff Bot Store`
5. Click **Create App**

### 3. Copy Your Credentials
After creating the app, you'll see:
- **Client ID** (Public key)
- **Secret** (Private key - keep this secret!)

**Sandbox Mode:**
- Client ID: `YOUR_SANDBOX_CLIENT_ID`
- Secret: `YOUR_SANDBOX_SECRET`

**Live Mode:**
- Client ID: `YOUR_LIVE_CLIENT_ID`
- Secret: `YOUR_LIVE_SECRET`

## 🚀 Installation

### 1. Install Dependencies
```bash
npm install express express-session @paypal/checkout-server-sdk typescript ts-node @types/express @types/express-session
```

### 2. Set Environment Variables

Create a `.env` file in the website directory:

```env
# PayPal Configuration
PAYPAL_CLIENT_ID=YOUR_SANDBOX_CLIENT_ID
PAYPAL_CLIENT_SECRET=YOUR_SANDBOX_SECRET
PAYPAL_MODE=sandbox

# For production, use:
# PAYPAL_MODE=live

# Server Configuration
PORT=5000
SESSION_SECRET=your-random-secret-key-here
NODE_ENV=development
```

### 3. Project Structure
```
website/
├── server.ts              # Express server with PayPal integration
├── routes/
│   └── dashboard.ts       # Dashboard routes
├── index.html             # Homepage
├── shop.html              # Shop with PayPal buttons
├── dashboard.html         # Dashboard
├── success.html           # Payment success page
├── cancel.html            # Payment cancelled page
├── assets/                # Images and resources
├── css/                   # Stylesheets
├── js/                    # JavaScript files
├── package.json
├── tsconfig.json
└── .env                   # Environment variables (create this)
```

## 🎯 How It Works

### Payment Flow

1. **User clicks PayPal button** → Frontend calls `/api/orders`
2. **Server creates order** → Returns `order.id` + `redemptionCode`
3. **User approves on PayPal** → PayPal redirects back with `orderID`
4. **Frontend calls capture** → Server captures payment with `/api/orders/:orderID/capture`
5. **Server confirms capture** → Returns transaction details
6. **Redirect to success page** → Shows redemption code

### API Endpoints

#### GET `/api/config`
Returns PayPal client ID for frontend SDK

**Response:**
```json
{
  "paypalClientId": "YOUR_CLIENT_ID",
  "configured": true
}
```

#### POST `/api/orders`
Creates a new PayPal order

**Request:**
```json
{
  "productId": "popular"
}
```

**Response:**
```json
{
  "id": "ORDER_ID_FROM_PAYPAL",
  "redemptionCode": "SHERIFF-POPULAR-ABC123"
}
```

#### POST `/api/orders/:orderID/capture`
Captures the payment

**Response:**
```json
{
  "orderID": "ORDER_ID",
  "status": "COMPLETED",
  "payer": {
    "email_address": "buyer@example.com"
  }
}
```

#### GET `/api/orders/:orderID`
Gets order details

**Response:**
```json
{
  "id": "ORDER_ID",
  "status": "COMPLETED",
  "purchaseUnits": [...],
  "payer": {...}
}
```

## 🧪 Testing

### Sandbox Test Accounts

PayPal provides test accounts for sandbox testing:

1. Go to **Dashboard** → **Sandbox** → **Accounts**
2. You'll see:
   - **Personal Account** (buyer) - Use this email/password to "buy"
   - **Business Account** (seller) - Receives the payments

### Test Credit Cards

For testing credit card payments in sandbox:
- **Visa:** `4032039613071332`
- **Mastercard:** `5425233430109903`
- **CVV:** Any 3 digits
- **Expiry:** Any future date

## 🔧 Configuration

### Switching to Live Mode

1. Create a **Live** app in PayPal Developer Dashboard
2. Update `.env`:
   ```env
   PAYPAL_CLIENT_ID=YOUR_LIVE_CLIENT_ID
   PAYPAL_CLIENT_SECRET=YOUR_LIVE_SECRET
   PAYPAL_MODE=live
   ```

3. ⚠️ **Important:** Test thoroughly in sandbox before going live!

### Products Configuration

Products are defined in `server.ts`:

```typescript
const PRODUCTS = {
    starter: {
        name: 'Starter Pack',
        description: '100 Saloon Tokens + 5,000 Silver Coins',
        price: 1.99,
        tokens: 100,
        coins: 5000
    },
    // ... more products
};
```

## 🛡️ Security Best Practices

1. **Never expose your Client Secret** - Keep it in `.env` only
2. **Use environment variables** - Don't hardcode credentials
3. **Verify payments server-side** - Don't trust client-side data
4. **Use HTTPS in production** - PayPal requires secure connections
5. **Validate webhook signatures** - If using webhooks

## 🚨 Common Issues

### Issue: "PayPal not configured"
**Solution:** Make sure `PAYPAL_CLIENT_ID` and `PAYPAL_CLIENT_SECRET` are set in `.env`

### Issue: "ORDER_NOT_APPROVED"
**Solution:** User cancelled payment. Show cancel page.

### Issue: "INSTRUMENT_DECLINED"
**Solution:** Payment method was declined. User should try another card.

### Issue: Buttons not showing
**Solution:** Check browser console for errors. Make sure PayPal SDK loads correctly.

## 📚 Resources

- [PayPal Developer Docs](https://developer.paypal.com/docs/)
- [Orders v2 API Reference](https://developer.paypal.com/docs/api/orders/v2/)
- [JavaScript SDK Reference](https://developer.paypal.com/sdk/js/reference/)
- [PayPal Checkout Server SDK](https://www.npmjs.com/package/@paypal/checkout-server-sdk)

## 🤝 Support

For PayPal integration issues:
- Check PayPal Developer Community
- Review server logs for detailed errors
- Test in sandbox mode first

For Sheriff Bot specific issues:
- Check Discord bot logs
- Verify redemption codes are being saved correctly
- Test `/redeem` command in Discord

## ✅ Deployment Checklist

- [ ] PayPal Live app created
- [ ] Environment variables set to LIVE credentials
- [ ] `PAYPAL_MODE=live` in production
- [ ] Tested all products in sandbox
- [ ] Redemption codes working in Discord
- [ ] HTTPS enabled on website
- [ ] Error handling tested
- [ ] Success/cancel pages working

---

**Ready to accept payments! 💰🤠**
